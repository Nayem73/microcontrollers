# Microcontroller-design
## Clock

![](images/01.png)