# Microcontroller-design
## Relay to controller DC and AC current

![](images/01.png)