# Microcontroller-design
## Seven segment displays

![](images/01.png)