char array_CA[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
void main() {
     short i = 0;
     TRISB = 0x00;
     portb = 0xff;
     
     while(1){
          portb = array_CA[i];
          delay_ms(500);
          i = (i+1)%10;
     }
}