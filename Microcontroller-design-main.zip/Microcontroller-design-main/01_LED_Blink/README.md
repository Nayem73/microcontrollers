# Microcontroller-design
## LED light configuration

![](images/01.png)