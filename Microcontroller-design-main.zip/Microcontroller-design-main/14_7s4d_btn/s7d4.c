char array_CA[]={0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
void main() {
     int i = 0, j, d1, d2, d3, d4, r;
     TRISB = 0x00;
     portb = 0x00;
     TRISD = 0x00;
     portd = 0x00;
     TRISC = 0xff;

     while(1){
     d1 = i/1000;
     r = i%1000;
     d2 = r/100;
     r = r % 100;
     d3 = r/10;
     d4 = r%10;


     portd.RD0 = 1;
     portb =   array_CA[d1];
     delay_ms(10);
     portd.RD0 = 0;

     portd.RD1 = 1;
     portb =   array_CA[d2];
     delay_ms(10);
     portd.RD1 = 0;


     portd.RD2 = 1;
     portb =   array_CA[d3];
     delay_ms(10);
     portd.RD2 = 0;


     portd.RD3 = 1;
     portb =   array_CA[d4];
     delay_ms(10);
     portd.RD3 = 0;
     
     if(portc.f6==1){
//     delay_ms(100);
     if(portc.f6==1){
     i++;
     }
     }
     
     if(portc.f7==1){
//     delay_ms(100);
     if(portc.f7==1){
     i--;
     }
     }

     

     }
}