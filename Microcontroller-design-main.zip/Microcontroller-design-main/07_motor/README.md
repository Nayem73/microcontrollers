# Microcontroller-design
## Motor controller. Bydirectional movement

![](images/01.png)