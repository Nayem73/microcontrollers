#include <stdio.h>  // Include this if your environment supports it
void delay_ms_variable(int delay) {
    int i, j;
    for(i = 0; i < delay; i+=10)
          delay_ms(10);
//        for(j = 0; j < 3180; j++) {}  // This number might need to be adjusted depending on your microcontroller's clock speed
}
int counter = 0;
int delay = 100;
void main() {
    TRISB = 0x00;
    PORTB = 0x00;


    while(counter < 20) {
        PORTB.RB7 = 1;
        delay_ms_variable(delay);
        PORTB.RB7 = 0;
        delay_ms_variable(delay);


        counter++;
        delay += 100;
    }
}