# Microcontroller-design
## Seven segment displays with increment and decrement buttons

![](images/01.png)