# Microcontroller-design
## Seven segment two digit displays

![](images/01.png)