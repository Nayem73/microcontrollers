# Microcontroller-design
## Seven segment two digit displays with increment and decrement buttons

![](images/01.png)